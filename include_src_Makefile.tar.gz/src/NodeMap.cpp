#include "NdoeMap.h"


CCSVWriter::NodeMap(std::ostream &ou) : output(ou)
{
  //std::ifstream input(filename);
  //CXMLReader reader(input);

}

CCSVWriter::~NodeMap()
{

}

void CCSVWriter::WriteRow(const std::vector<std::string> &row)
{
  //make node and way objects

}
